#include<iostream>
#include<time.h>
using namespace std;

class CPrintString
{
public:
	CPrintString() {};
	~CPrintString() {};

public:
	void PrintfText(const char* s) { printf(s); };
	static void StaticPrintText(void* ptClass, const char* s);
};
void CPrintString::StaticPrintText(void* ptClass, const char* s)
{
	CPrintString* ptThis = static_cast<CPrintString*>(ptClass);
	if (NULL == ptClass)
	{
		return;
	}

	ptThis->PrintfText(s);
}

typedef void(*PPRINTTEXT)(void* ptClass, const char* s);
void CallPrintText(void* ptClass, const char *s, PPRINTTEXT fp)
{
	fp(ptClass, s);
}

int main()
{
	CPrintString obj;
	CallPrintText((void*)&obj, "Hello World!\n", CPrintString::StaticPrintText);
	/*int a = 1;
	int b = 1000;

	srand((unsigned)time(NULL));
	for (int i = 0; i < 10; i++)
		cout << (rand() % (b - a + 1)) + a << '\t';

	cout << "\n";
	

	
	for (int i = 0; i < 10; i++)
		cout << (rand() % (b - a + 1)) + a << '\t';

	cout << "\n";


	for (int i = 0; i < 10; i++)
		cout << (rand() % (b - a + 1)) + a << '\t';

	cout << "\n";


	for (int i = 0; i < 10; i++)
		cout << (rand() % (b - a + 1)) + a << '\t';
	cout << endl;*/

}