#include<GL/glut.h>
#include<iostream>
#include<math.h>
#include<conio.h>
#include<graphics.h>
#include <time.h> 
using namespace std;

void IntegerBresenhamline(int x0, int y0, int x1, int y1, int color)
{
	int x, y, dx, dy, e, i;
	dx = x1 - x0;
	dy = y1 - y0;
	e = -dx;
	x = x0;
	y = y0;
	for (i = 0; i <= dx; i++)
	{
		Sleep(5);
		putpixel(x, y, color);
		x++;
		e = e + 2 * dy;
		if (e >= 0) { y++; e = e - 2 * dx; }
	}
}

void main()
{
	
	const int z = 0;
	const int a = 600;
	const int b = 400;
	int k =10;//�˵����

	initgraph(a, b);

	int* x0 = new int[k];
	int* y0 = new int[k];
	int* x1 = new int[k];
	int* y1 = new int[k];


	srand((unsigned)time(NULL));

	for (int i = 0; i < k; i++)
		x0[i] = (rand() % (a - z + 1)) + z;
	
	for (int i = 0; i < k; i++)
		y0[i] = (rand() % (b - z + 1)) + z;
	
	for (int i = 0; i < k; i++)
		x1[i] = (rand() % (a - z + 1)) + z;

	for (int i = 0; i < k; i++)
		y1[i] = (rand() % (a - z + 1)) + z;

	for (int i = 0; i < k; i++)
		IntegerBresenhamline(x0[i], y0[i], x1[i], y1[i], GREEN);


	_getch();
	closegraph();
}